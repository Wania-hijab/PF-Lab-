#include<iostream>
using namespace std;
int main () {
	int num;
	cout<<"Enter a number";
	cin>>num;
	if (num>0) {
		if (num>100) {
			cout<<"The number is large"; }
			else if (num<=100) {
				cout<<"Number is small"; } }
				else if (num<0) {
					if(num<-100) {
						cout<<"The number is very small"; }
						else if (num>=-100) {
							cout<<"The number is small and negative"; } }
							else if (num==0) {
								cout<<"Number is zero";}
			
		return 0;
	}
