#include<iostream>
using namespace std;
int main() {
	int day;
	cout<<"Enter a number to represent a day of the week."<<endl;
	cout<<"1. Monday"<<endl;
	cout<<"2. Tuesday"<<endl;
	cout<<"3. Wednesday"<<endl;
	cout<<"4. Thursday"<<endl;
	cout<<"5. Friday"<<endl;
	cout<<"6. Saturday"<<endl;
	cout<<"7. Sunday"<<endl;
	cin>>day;
switch(day) {
	case 1:
		cout<<"Start of the workweek.";
		break;
	case 2:
		cout<<"It's Tuesday, stay productive'.";
		break;
	case 3:
		cout<<"Midweek motivation!";
		break;
	case 4:
		cout<<"Almost the weekend.";
		break;
	case 5:
		cout<<"TGIF!";
		break;
	case 6:
		cout<<"Relax, it's saturday.";
		break;
	case 7:
		cout<<"Enjoy your Sunday!";
		break;
	case 8:
		cout<<"Invalid day selection.";
		break;
}
return 0;
}