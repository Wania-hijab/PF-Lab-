#include<iostream>
using namespace std;
int main() {
	char service;
	char D,W,T;
	cout<<"Enter type of servie"<<endl;
	cout<<"D=Deposit"<<endl;
	cout<<"W=Withdraw"<<endl;
	cout<<"T=Transfer"<<endl;
	cin>>service;
	
	switch(service) {
		case 'D':
			cout<<"Deposit = 0.5% charges of deposited amount";
			break;
		case 'W':
			cout<<"Withdraw = 1.5% charges of withdraw amount";
			break;
		case 'T':
			cout<<"Transfer = 2.5% charges of transfer amount";
			break;
	}
return 0;
}