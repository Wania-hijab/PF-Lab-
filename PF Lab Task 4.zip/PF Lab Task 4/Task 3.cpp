#include<iostream>
using namespace std;
int main() {
int a,b,c,d,num1,num2;
int op;
cout<<"Enter the number of an operation from the following menu"<<endl;
cout<<"1. '+'"<<endl;
cout<<"2. '-'"<<endl;
cout<<"3. '*'"<<endl;
cout<<"4. '/'"<<endl;
cin>>op;
cout<<"Enter two numbers";
cin>>num1>>num2;
a=num1+num2;
b=num1-num2;
c=num1*num2;
d=num1/num2;
switch(op) {
	case 1:
	cout<<num1<<"+"<<num2<<"="<<a;
	break;
	case 2:
	cout<<num1<<"-"<<num2<<"="<<b;
	break;
	case 3:
	cout<<num1<<"*"<<num2<<"="<<c;
	break;
	case 4:
	cout<<num1<<"/"<<num2<<"="<<d;
	break;
}
return 0;
}