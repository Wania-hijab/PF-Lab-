#include<iostream>
using namespace std;
int main () {
	float celsius,fahrenheit;
	cout<<"Temperature in celsius= ";
	cin>>celsius;
	fahrenheit=(celsius*9/5)+32;
	cout<<"Temperature in fahrenheit= "<<fahrenheit;
return 0;
}