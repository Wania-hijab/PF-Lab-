#include<iostream>
using namespace std;
int main () {
	double area,length,width,perimeter;
	cout<<"Enter length"<<endl;
	cin>>length;
	cout<<"Enter width"<<endl;
	cin>>width;
	area=length*width;
	perimeter=2*(length+width);
	cout<<"Area= "<<area<<endl;
	cout<<"Perimeter= "<<perimeter;
return 0;
}