#include<iostream>
using namespace std;
int main () {
	float num1,num2,num3,sum,percentage;
	cout<<"Enter marks of Physics"<<endl;
	cin>>num1;
	cout<<"Enter marks of PF"<<endl;
	cin>>num2;
	cout<<"Enter marks of ICT"<<endl;
	cin>>num3;
	sum=num1+num2+num3;
	percentage=(sum/300)*100;
	cout<<"Percentage= "<<percentage<<endl;
	if(percentage>=90) {
		cout<<"Grade A";
	}
	else if(percentage>=80) {
		cout<<"Grade B";
	}
	else if(percentage>=70) {
		cout<<"Grade C";
	}
	else if(percentage>=60) {
		cout<<"Grade D";
	}
	else{
		cout<<"Grade F";
	}
return 0;
}