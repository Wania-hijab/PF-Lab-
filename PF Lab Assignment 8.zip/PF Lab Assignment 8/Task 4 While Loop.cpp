#include<iostream>
using namespace std;
int main() {
	int i, num, factorial=1;
		cout<<"Enter a number: ";
	cin>>num;
	
	while(i<=num) {
		int j;
		
		while(j<=i) {
			if (j==1) {
				factorial=1;
			} else {
			
			factorial *= j;
	        }
        j++;
		}
		
		i++;
	}
	cout << "Factorial of " << num << " is: " << factorial << endl;

return 0;
}