#include <iostream>
using namespace std;

int main() {
    int num, factorial = 1;

    cout << "Enter a number: ";
    cin >> num;

    int i = 1;
    do {
        int j;
        do {
            if (j == 1) {
                factorial = 1;
            } else {
                factorial *= j;
            }
            j++;
        } while (j <= i);
        i++;
    } while (i <= num);

    cout << "The factorial of " << num << " is: " << factorial << endl;

    return 0;
}
