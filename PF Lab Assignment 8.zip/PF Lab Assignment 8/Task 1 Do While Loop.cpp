#include<iostream>
using namespace std;
int main() {
	int rows=7,j,i=1;
	do{ 
		j=1;
		do{
			cout<<"*";
			j++;
		}while (j<=i);
		    cout<<"\n";
		    i++;
	}while(i<=rows);
	
return 0;
}