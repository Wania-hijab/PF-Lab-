#include<iostream>
using namespace std;
int main() {
	int rows=9,j,i=1;
	do{ 
		j=1;
		do{
			cout<<"*";
			j++;
		}while (j<=9);
		    cout<<"\n";
		    i++;
	}while(i<=rows);
	
return 0;
}