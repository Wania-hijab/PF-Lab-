#include<iostream>
using namespace std;
int main() {
	int num,j;
	int factorial=1;
	cout<<"Enter a number: ";
	cin>>num;
	
	for(int i=1;i<=num;i++) {
		
		for(j=1;j<=i;j++) {
			if (j==1){
				factorial = 1;
			} else{
			
			factorial *= j;
	        }
		}
	cout<<"";
    }
	cout << "Factorial of " << num << " is: " << factorial << endl;
	return 0;
}