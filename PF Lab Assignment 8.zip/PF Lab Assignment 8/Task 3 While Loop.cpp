#include<iostream>
using namespace std;
int main() {
	int rows=9, i=1;
	while(i<=rows) {
		int j=1;
		while(j<=9) {
			cout<<"*";
			j++;
		}
		cout<<"\n";
		i++;
	}
return 0;
}