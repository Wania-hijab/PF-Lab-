#include<iostream>
using namespace std;
int main() {
	int rows=7, i=1;
	while(i<=rows) {
		int j=1;
		while(j<=i) {
			cout<<"*";
			j++;
		}
		cout<<"\n";
		i++;
	}
return 0;
}